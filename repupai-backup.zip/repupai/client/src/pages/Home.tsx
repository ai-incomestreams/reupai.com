import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowRight, Globe, Lock, Zap, Calendar, Shield } from "lucide-react";
import { useState } from "react";

/**
 * RepupAI Landing Page
 * 
 * Design System:
 * - Color: Deep Purple (#6D28D9) + Electric Cyan (#00D9FF)
 * - Typography: Sora (display) + Inter (body)
 * - Layout: Asymmetric with diagonal dividers
 * - Interactions: Smooth transitions, hover effects, scroll animations
 * - Focus: In-house trained AI models for reputation management
 */

export default function Home() {
  const [demoOpen, setDemoOpen] = useState(false);
  const [demoForm, setDemoForm] = useState({ name: "", email: "", company: "" });

  const headlines = [
    "Reputation Management Built on Custom AI",
    "Your Brand's AI Guardian",
    "Where AI Meets Reputation"
  ];



  const handleDemoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send to your backend
    console.log("Demo request:", demoForm);
    alert(`Demo scheduled! We'll contact you at ${demoForm.email}`);
    setDemoForm({ name: "", email: "", company: "" });
    setDemoOpen(false);
  };

  return (
    <div className="min-h-screen bg-white text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary/60 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">R</span>
            </div>
            <span className="font-display font-bold text-lg">RepupAI</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#contact" className="text-sm font-medium text-primary hover:text-primary/80 transition-colors">
              Get Started
            </a>
            <Dialog open={demoOpen} onOpenChange={setDemoOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-2">
                  <Calendar className="w-4 h-4" />
                  Get Demo
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Schedule Your Demo</DialogTitle>
                  <DialogDescription>
                    Book a personalized demo with our team to see RepupAI in action
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleDemoSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Your name"
                      value={demoForm.name}
                      onChange={(e) => setDemoForm({ ...demoForm, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={demoForm.email}
                      onChange={(e) => setDemoForm({ ...demoForm, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company">Company</Label>
                    <Input
                      id="company"
                      placeholder="Your company"
                      value={demoForm.company}
                      onChange={(e) => setDemoForm({ ...demoForm, company: e.target.value })}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                    Schedule Demo
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Text */}
            <div className="space-y-6 lg:pr-8">
              <div className="inline-block px-4 py-2 bg-secondary rounded-full">
                <span className="text-sm font-medium text-secondary-foreground">Powered by Custom AI Models</span>
              </div>
              <h1 className="font-display font-bold text-5xl md:text-6xl leading-tight bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                {headlines[0]}
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-xl">
                Our custom LLMs understand reputation dynamics across any industry. We don't just monitor—we analyze, interpret, and recommend intelligent responses. Your AI learns your brand's voice and suggests strategic actions that protect and grow your reputation across geographies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <a href="#contact">
                  <Button size="lg" className="gap-2 bg-primary hover:bg-primary/90">
                    Start Free Trial <ArrowRight className="w-4 h-4" />
                  </Button>
                </a>
                <Dialog open={demoOpen} onOpenChange={setDemoOpen}>
                  <DialogTrigger asChild>
                    <Button size="lg" variant="outline" className="gap-2">
                      <Calendar className="w-4 h-4" />
                      Get Demo
                    </Button>
                  </DialogTrigger>
                </Dialog>
              </div>
            </div>

            {/* Right: Hero Image */}
            <div className="relative h-96 lg:h-full min-h-96 rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663313468002/eENskSPLN6KrFw8zsXLAeP/repupai-hero-brain-ai-KXWzgYF2EgHdvkpCzYwFv3.webp"
                alt="RepupAI AI Brain Hero"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Diagonal Divider */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-b from-transparent to-secondary/30 pointer-events-none" />
      </section>

      {/* Exclusivity Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 border-y border-border">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-block px-4 py-2 bg-primary/10 rounded-full mb-6">
              <span className="text-sm font-semibold text-primary">Our Commitment to Excellence</span>
            </div>
            <h2 className="font-display font-bold text-3xl md:text-4xl mb-6">
              One Company Per Industry. Per Geography.
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              We don't believe in serving multiple competitors in the same market. When we partner with you, we commit to your exclusive success. <span className="font-semibold text-foreground">Once we close the deal, we don't serve any other company in your industry within your geography.</span> This means your reputation strategy remains confidential, your competitive advantages stay protected, and our entire focus is on your growth.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              <div className="p-6 bg-white rounded-lg border border-border">
                <div className="text-2xl font-display font-bold text-primary mb-2">100%</div>
                <p className="text-sm text-muted-foreground">Dedicated Focus</p>
              </div>
              <div className="p-6 bg-white rounded-lg border border-border">
                <div className="text-2xl font-display font-bold text-primary mb-2">Zero</div>
                <p className="text-sm text-muted-foreground">Competitor Conflicts</p>
              </div>
              <div className="p-6 bg-white rounded-lg border border-border">
                <div className="text-2xl font-display font-bold text-primary mb-2">100%</div>
                <p className="text-sm text-muted-foreground">Confidential Strategy</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rotating Headlines Section */}
      <section className="py-16 bg-secondary/20 relative">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {headlines.map((headline, index) => (
              <div key={index} className="text-center p-6 bg-white rounded-xl border border-border hover:border-primary/50 transition-all hover:shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <p className="font-display font-bold text-lg text-primary">
                  {headline}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
              Why Choose RepupAI?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive AI-driven solutions built on custom-trained models
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1: AI Intelligence */}
            <div className="group bg-white rounded-xl p-8 border border-border hover:border-primary/50 transition-all hover:shadow-lg">
              <div className="mb-6 relative h-48 rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663313468002/eENskSPLN6KrFw8zsXLAeP/repupai-feature-brain-thinking-HmBsAcWLDFB7zBdX3qN6ua.webp"
                  alt="AI Brain Thinking"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-bold text-xl">Custom AI Models</h3>
              </div>
              <p className="text-muted-foreground">
                Our custom LLMs analyze sentiment, competitive positioning, and market dynamics to recommend intelligent responses. We don't just report—we help you reply strategically to protect and grow your reputation.
              </p>
            </div>

            {/* Feature 2: Geographic Reach */}
            <div className="group bg-white rounded-xl p-8 border border-border hover:border-primary/50 transition-all hover:shadow-lg">
              <div className="mb-6 relative h-48 rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663313468002/eENskSPLN6KrFw8zsXLAeP/repupai-feature-global-presence-XLkobfA3pKFHWoQBURSLbg.webp"
                  alt="Global Presence"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Globe className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-bold text-xl">Global Coverage</h3>
              </div>
              <p className="text-muted-foreground">
                Our AI understands that reputation varies by market. We help you craft region-specific strategies, ensuring your brand dominates local search results where it matters most.
              </p>
            </div>

            {/* Feature 3: Trust & Security */}
            <div className="group bg-white rounded-xl p-8 border border-border hover:border-primary/50 transition-all hover:shadow-lg">
              <div className="mb-6 relative h-48 rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663313468002/eENskSPLN6KrFw8zsXLAeP/repupai-feature-reputation-shield-btLQi3US8qRoeTib2LZETy.webp"
                  alt="Reputation Shield"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Lock className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-bold text-xl">Enterprise Security</h3>
              </div>
              <p className="text-muted-foreground">
                Your brand data remains completely confidential. We never use your data to train models or share insights with competitors. Enterprise-grade security and full compliance.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-secondary/20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
              How Our AI Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Three simple steps to elevate your online reputation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { num: 1, title: "Connect Your Presence", desc: "Link all your business profiles and online channels to our AI system." },
              { num: 2, title: "AI Analysis", desc: "Our custom models analyze mentions, sentiment, and geographic reach in real-time." },
              { num: 3, title: "Optimize & Grow", desc: "Receive AI-powered recommendations to boost your brand visibility." }
            ].map((step) => (
              <div key={step.num} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent text-white rounded-full flex items-center justify-center font-display font-bold text-2xl mb-6">
                    {step.num}
                  </div>
                  <h3 className="font-display font-bold text-xl mb-3">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {step.desc}
                  </p>
                </div>
                {step.num < 3 && (
                  <div className="hidden md:block absolute top-8 -right-4 w-8 h-1 bg-gradient-to-r from-primary to-accent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to know about our custom AI models and reputation management
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border border-border rounded-lg px-6">
                <AccordionTrigger className="hover:no-underline py-4 font-display font-bold text-lg">
                  What makes RepupAI's AI different from generic reputation tools?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  Our custom LLMs are trained to understand reputation dynamics across <span className="font-semibold text-foreground">any industry</span>—not generic chatbots. We don't just monitor mentions; we analyze sentiment, competitive positioning, and geographic impact, then recommend intelligent responses. Our AI learns your brand's voice and suggests strategic actions that protect and grow your reputation.
                  <br /><br />
                  <span className="font-semibold text-foreground">The difference?</span> We don't just report—we reply strategically. Instead of passive alerts, you get actionable recommendations grounded in your market dynamics. Clients typically see:
                  <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                    <li>25-40% improvement in local search visibility within 3-5 months</li>
                    <li>Increased appearance in generative AI recommendations</li>
                    <li>Better organic traffic from location-based searches</li>
                    <li>Higher conversion rates because prospects see positive brand signals first</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="border border-border rounded-lg px-6">
                <AccordionTrigger className="hover:no-underline py-4 font-display font-bold text-lg">
                  How does custom AI training improve brand visibility?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  <span className="font-semibold text-foreground">Local Search Impact:</span> Your star ratings, review count, and review recency directly influence your position in the local pack (the 3 results in Google Maps). Positive reviews and strategic responses improve your Local SEO score. When someone searches '[your service] near me' or '[your service] in [city]', Google prioritizes businesses with strong reputation signals.
                  <br /><br />
                  <span className="font-semibold text-foreground">Generative AI Discovery:</span> When prospects ask ChatGPT, Gemini, or Claude 'where should I find [service] in [location]?', these AI models are trained on reputation data. Strong online reputation increases your chances of being recommended by generative AI.
                  <br /><br />
                  <span className="font-semibold text-foreground">The real impact?</span> Clients who actively manage their reputation with our AI see:
                  <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                    <li>30-50% increase in local search rankings</li>
                    <li>Higher click-through rates from location-based searches</li>
                    <li>Improved trust signals that Google's algorithm rewards</li>
                    <li>Appearance in generative AI recommendations</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="border border-border rounded-lg px-6">
                <AccordionTrigger className="hover:no-underline py-4 font-display font-bold text-lg">
                  Why is geographic targeting important for reputation management?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  Most reputation tools treat all mentions equally. Our AI understands that a negative review in your key market has different strategic importance than one in a region where you don't operate. We prioritize reputation management where it matters most to your business.
                  <br /><br />
                  <span className="font-semibold text-foreground">What this means for you:</span> If you operate in 5 countries, our AI helps you craft region-specific responses and strategies, ensuring your brand dominates local search results where it matters most. This geographic intelligence directly translates to better local SEO rankings and higher visibility in your target markets.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="border border-border rounded-lg px-6">
                <AccordionTrigger className="hover:no-underline py-4 font-display font-bold text-lg">
                  How quickly will I see results?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  SEO is a marathon, not a sprint. Most clients see measurable improvements in brand visibility and local search rankings within <span className="font-semibold text-primary">3-5 months</span>, depending on your starting reputation baseline and competitive landscape.
                  <br /><br />
                  <span className="font-semibold text-foreground">What improves first:</span>
                  <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                    <li>Local search rankings (Google Maps, 'near me' searches)</li>
                    <li>Review ratings visibility and star ratings in search results</li>
                    <li>Click-through rates from local search results</li>
                    <li>Brand mentions in local directories and citations</li>
                  </ul>
                  <br />
                  <span className="font-semibold text-foreground">Why 3-5 months?</span> Search engines need time to observe consistent reputation signals. Our AI accelerates this by ensuring you're responding strategically to every reputation opportunity—but Google still needs to see the pattern.
                  <br /><br />
                  <span className="font-semibold text-foreground">The long-term play:</span> After 3-5 months, you'll have built enough reputation momentum that your brand dominates local search, appears in generative AI responses, and your organic traffic compounds month-over-month.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="border border-border rounded-lg px-6">
                <AccordionTrigger className="hover:no-underline py-4 font-display font-bold text-lg">
                  Is my data secure with custom AI models?
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  Your brand data, client feedback, and strategic insights remain completely confidential. We never use your data to train our models or share insights with competitors. We use enterprise-grade encryption and comply with <span className="font-semibold text-foreground">GDPR, SOC 2, and ISO 27001</span> standards.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20 bg-gradient-to-br from-primary/5 to-accent/5 relative overflow-hidden">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display font-bold text-4xl md:text-5xl mb-6">
              Ready to Transform Your Reputation?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join businesses using RepupAI's custom AI models to manage and grow their online reputation across geographies.
            </p>

            {/* Contact Card */}
            <div className="bg-white rounded-2xl p-8 md:p-12 border border-border shadow-lg">
              <p className="text-muted-foreground mb-4">Get in touch with our team</p>
              <a
                href="mailto:connect@repupai.com"
                className="inline-flex items-center gap-2 text-2xl font-display font-bold text-primary hover:text-primary/80 transition-colors"
              >
                connect@repupai.com
                <ArrowRight className="w-6 h-6" />
              </a>
              <p className="text-sm text-muted-foreground mt-6">
                We typically respond within 24 hours
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border bg-white">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-2 mb-6 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">R</span>
              </div>
              <span className="font-display font-bold">RepupAI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2026 RepupAI. All rights reserved. | AI-Powered Online Reputation Management
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
